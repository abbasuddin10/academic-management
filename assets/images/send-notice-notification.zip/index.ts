import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from "https://esm.sh/@supabase/supabase-js@2"

async function getAccessToken(): Promise<string> {
  const clientEmail = Deno.env.get('FIREBASE_CLIENT_EMAIL') ?? ''
  const rawKey = Deno.env.get('FIREBASE_PRIVATE_KEY') ?? ''
  const privateKey = rawKey.replace(/\\n/g, '\n')

  const pubKey = await crypto.subtle.importKey(
    "pkcs8",
    base64ToArrayBuffer(privateKey),
    { name: "RSASSA-PKCS1-v1_5", hash: "SHA-256" },
    false,
    ["sign"]
  )

  const header = { alg: "RS256", typ: "JWT" }
  const now = Math.floor(Date.now() / 1000)
  const payload = {
    iss: clientEmail,
    scope: "https://www.googleapis.com/auth/firebase.messaging",
    aud: "https://oauth2.googleapis.com/token",
    exp: now + 3600,
    iat: now,
  }

  const encodedHeader = btoa(JSON.stringify(header))
  const encodedPayload = btoa(JSON.stringify(payload))
  const unsignedToken = `${encodedHeader}.${encodedPayload}`

  const signature = await crypto.subtle.sign(
    "RSASSA-PKCS1-v1_5",
    pubKey,
    new TextEncoder().encode(unsignedToken)
  )

  const encodedSignature = btoa(String.fromCharCode(...new Uint8Array(signature)))
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "")

  const jwt = `${unsignedToken}.${encodedSignature}`

  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: `grant_type=urn%3Aietf%3Aparams%3Aoauth%3Agrant-type%3Ajwt-bearer&assertion=${jwt}`,
  })

  const data = await res.json()
  return data.access_token
}

function base64ToArrayBuffer(b64: string) {
  const cleanB64 = b64.replace(/-----BEGIN PRIVATE KEY-----/, '').replace(/-----END PRIVATE KEY-----/, '').replace(/\s/g, '')
  const binaryString = atob(cleanB64)
  const bytes = new Uint8Array(binaryString.length)
  for (let i = 0; i < binaryString.length; i++) {
    bytes[i] = binaryString.charCodeAt(i)
  }
  return bytes.buffer
}

serve(async (req) => {
  try {
    const payload = await req.json()
    const notice = payload.record 

    if (!notice) {
      return new Response(JSON.stringify({ message: "No notice record found" }), { status: 400 })
    }

    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    let allTokens: string[] = []
    const academyId = notice.academy_id

    // ১. যদি নোটিশ "সকল ছাত্র-ছাত্রী" বা "সবাই" এর জন্য হয়
    if (notice.target_type === 'all_students' || notice.target_type === 'everyone') {
      const { data: students } = await supabaseClient
        .from('students')
        .select('fcm_token')
        .eq('academy_id', academyId)
      
      if (students) {
        const tokens = students.map(s => s.fcm_token).filter(Boolean)
        allTokens.push(...tokens)
      }
    } 
    // ২. যদি নোটিশ "নির্দিষ্ট ক্লাস" এর জন্য হয়
    else if (notice.target_type === 'class' && notice.target_class) {
      const { data: students } = await supabaseClient
        .from('students')
        .select('fcm_token')
        .eq('academy_id', academyId)
        .eq('class', notice.target_class)

      if (students) {
        const tokens = students.map(s => s.fcm_token).filter(Boolean)
        allTokens.push(...tokens)
      }
    } 
    // ৩. যদি নোটিশ "শিক্ষক" দের জন্য হয় (users টেবিল থেকে)
    else if (notice.target_type === 'teachers') {
      const { data: teachers } = await supabaseClient
        .from('users')
        .select('fcm_token')
        .eq('academy_id', academyId)
        .eq('role', 'teacher')

      if (teachers) {
        const tokens = teachers.map(t => t.fcm_token).filter(Boolean)
        allTokens.push(...tokens)
      }
    }

    // ডুপ্লিকেট টোকেন বাদ দেওয়া
    const uniqueTokens = [...new Set(allTokens)]

    if (uniqueTokens.length === 0) {
      return new Response(JSON.stringify({ message: "No tokens found for this target" }), { status: 200 })
    }

    const accessToken = await getAccessToken()
    const projectId = Deno.env.get('FIREBASE_PROJECT_ID')

    // ফায়ারবেস ক্লাউড মেসেজিং (FCM v1) এর মাধ্যমে নোটিফিকেশন পাঠানো
    const sendPromises = uniqueTokens.map(async (token) => {
      const message = {
        message: {
          token: token,
          notification: {
            title: notice.title,
            body: notice.description,
          },
          data: {
            click_action: "FLUTTER_NOTIFICATION_CLICK",
            id: notice.id || "",
          },
        },
      }

      const res = await fetch(`https://fcm.googleapis.com/v1/projects/${projectId}/messages:send`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Authorization: `Bearer ${accessToken}`,
        },
        body: JSON.stringify(message),
      })
      return res.json()
    })

    await Promise.all(sendPromises)

    return new Response(JSON.stringify({ success: true, sentCount: uniqueTokens.length }), {
      headers: { "Content-Type": "application/json" },
      status: 200,
    })
  } catch (err) {
    return new Response(JSON.stringify({ error: err.message }), { status: 500 })
  }
})